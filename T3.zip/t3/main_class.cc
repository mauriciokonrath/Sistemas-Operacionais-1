#include "main_class.h"

__BEGIN_API

Thread *Main::ping_pong_threads[5];

__END_API
