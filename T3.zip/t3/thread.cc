#include "thread.h"
#include <iostream>


__BEGIN_API
// Inicializa 
Thread * Thread::_running = 0;
unsigned int Thread::_thread_counter = 0;
Thread Thread::_main; // Thread main
Thread Thread::_dispatcher; // Thread dispatcher
CPU::Context Thread::_main_context; // Contexto da main
Thread::Ready_Queue Thread::_ready; //Filas prontas


// Métodos da classe thread
// Inicializa a thread e suas estruturas de dados associados 
 void Thread::init(void (*main)(void *))
{
    db<Thread>(TRC) << "Main e Dispatcher inicializados\n";    
    new (&_ready) Thread::Ready_Queue(); // Instancia a fila de threads prontas (cria a estrutura de dados responsável por armazenar as threads prontas para execução)  
    new (&_main) Thread(main, (void *) "main");// Instancia a thread Main    
    new (&_main_context) CPU::Context();// Instancia main context
    // Instancia a thread Dispatcher 
    new (&_dispatcher) Thread((void (*) (void *)) &Thread::dispatcher, (void *) NULL); // Cast para void pointer do método dispatcher, 
                                                                                      //   em seguida é feito um cast para void do conteúdo desse void pointer
    // Atualiza o ponteiro da thread em execução e altera o estado da main para RUNNING
    Thread::_running = &Thread::_main; // Atualizado para apontar para a thread principal _main
    Thread::_main._state = RUNNING;
    CPU::switch_context(&_main_context, _main.context()); // Troca de contexto de fato, transferindo o controle da CPU para a thread principal
};

// Implementa a função dispatcher da classe Thread (escolher a próxima thread a ser executada e trocar o contexto da CPU para a nova thread)
void Thread::dispatcher()
{
    db<Thread>(TRC) << "Dispatcher agendado.\n";
    while (Thread::_thread_counter > 2) {   // Enquanto houver mais de uma thread criada, comparando o valor do  com 2, porque as duas primeiras threads criadas são o dispatcher e a main   
        Thread * next = Thread::_ready.remove()->object(); // Escolhe primeira thread da fila para ser executada
        // Verifica se a próxima thread a ser executada é diferente do próprio dispatcher, antes de adicioná-lo de volta à fila 
        // Assim, o dispatcher só será executado novamente quando nenhuma outra thread estiver pronta para ser executada
         if (next != &Thread::_dispatcher) {  // Se a próxima thread a ser executada for diferente do próprio dispatcher
            Thread::_dispatcher._state = READY; // Thread do dispatcher é adicionada de volta à fila _ready
            Thread::_ready.insert(&Thread::_dispatcher._link);
        }
        Thread::_running = next; // Atualiza o ponteiro _running para apontar para a próxima
        next->_state = RUNNING; // Atualiza estado

        Thread::switch_context(&Thread::_dispatcher, next);// Troca o contexto
        if (next->_state == FINISHING) { //Se a thread que acabou de ser executada estiver no estado FINISHING, 
            Thread::_ready.remove(next); // ela é removida da fila _ready usando o método remove
        }
    }
    // Depois que todas as threads terminam de executar
    Thread::_dispatcher._state = FINISHING;  // O estado do dispatcher é atualizado para FINISHING
    Thread::_ready.remove(&Thread::_dispatcher); // Dispatcher é removido da fila _ready. 
    Thread::switch_context(&Thread::_dispatcher, &Thread::_main); // Contexto da CPU é trocado novamente para a thread principal _main.
};

// Responsável por ceder a execução da thread atual e agendar a próxima thread a ser executada
void Thread::yield()
{
    db<Thread>(TRC) << " Thread " << Thread::_running->id() <<" yielding\n";
    
    Thread * prev = Thread::_running; // Mantém a referência da thread a ser substituída    
    Thread * next = Thread::_ready.remove()->object(); // Remove da fila e retorna o ponteiro para a thread em questão

    // Atualiza a prioridade da tarefa que estava sendo executada [Thread::running]
    // Isso ocorre apenas de ela não estiver finalizando e não for a main
    if (prev->_state != FINISHING && prev != &Thread::_main) 
    {
        
        prev->_link.rank(std::chrono::duration_cast<std::chrono::microseconds> // Atualiza a posição da thread na lista usando o método rank do objeto _link
            (std::chrono::high_resolution_clock::now().time_since_epoch()).count());        
        prev->_state = READY; // Reinsere
        Thread::_ready.insert(&prev->_link);
    }

    // Atualiza running e troca o contexto
    Thread::_running = next;
    next->_state = RUNNING;
    Thread::switch_context(prev, next);
}

int Thread::switch_context(Thread * prev, Thread * next) 
{   
    
    // Verifica se não são a mesma thread
    if (prev->id() != next->id()) {
        Thread::_running = next;
        db<Thread>(TRC) << "Trocou de " <<  prev->id() << " para " << next->id() <<"\n";
        return CPU::switch_context(prev->context(), next->context());
    }    
    return 0;
};
// Finalizar a thread que a invoca
void Thread::thread_exit (int exit_code) 
{
    db<Thread>(TRC) << "Thread " << id() << ", codigo de saida: " << exit_code << "\n";
    Thread::_thread_counter--; // Decrementada para indicar que uma thread a menos está sendo executada
    _exit_code = exit_code; // Atualizada com o código de saída
    _state = FINISHING;
   Thread::yield(); // Seleciona a próxima thread a ser executada pelo escalonador
};

int Thread::id() 
{
    return _id;
};

CPU::Context * Thread::context()
{
    return _context;
};

Thread::~Thread() {
     db<Thread>(TRC) << "Thread " << id() << " finalizada\n";
    if (_context) {
        delete _context;
    }
};

__END_API