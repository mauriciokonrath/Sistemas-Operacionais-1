#include "thread.h"
#include <iostream>


__BEGIN_API

Thread * Thread::_running = 0;
unsigned int Thread::_thread_counter = 0;

int Thread::switch_context(Thread * prev, Thread * next) 
{   
    
    // Verifica se não são a mesma thread
    if (prev->id() != next->id()) {
        Thread::_running = next;
        db<Thread>(TRC) << "Trocou de " <<  prev->id() << " para " << next->id() <<"\n";
        return CPU::switch_context(prev->context(), next->context());
    }    
    return 0;
};

void Thread::thread_exit (int exit_code) 
{
    db<Thread>(TRC) << ">> Thread " << id() << ", codigo saida: " << exit_code << "\n";
    code_exit = exit_code;
    _thread_counter--;
};

int Thread::id() 
{
    return _id;
};

CPU::Context * Thread::context()
{
    return _context;
};

Thread::~Thread() {
     db<Thread>(TRC) << "Thread " << id() << " finalizada\n";
    if (_context) {
        delete _context;
    }
};

__END_API